$( document ).ready(function() {
  $(".rond").on('click', function() {
    $('html, body').animate({scrollTop: 0}, 4000);
     
  });

  $("#txtbtn").on('click', function() {
    $('html, body').animate({scrollTop: 2600}, 4000);
        
  });

  $("#page2").on('click', function() {
    $('html, body').animate({scrollTop: 1100}, 4000);
        
  });






});






